package abc;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TestCalculator {

	@Before
	public void setUp() throws Exception {
		System.out.println("befor test start");
	}

	@After
	public void tearDown() throws Exception {
		System.out.println("test over");
	}

	@Test
	public final void testAdd() {
		Calculator c=new Calculator();
		assertEquals(30,c.add(10, 20));
		
	}
	@Test
	public final void testSubtract() {
		Calculator c=new Calculator();
		assertEquals(30,c.subtract(40, 10));
		
	}

}
