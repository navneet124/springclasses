package annotation;

import org.springframework.beans.factory.annotation.Value;

public class Publisher {

	@Value("ravi")
	private String pname;
	@Value("pune")
	private String addr;

	@Override
	public String toString() {
		return "Publisher [pname=" + pname + ", addr=" + addr + "]";
	}

	public Publisher() {
		super();
	}

	public Publisher(String pname, String addr) {
		super();
		this.pname = pname;
		this.addr = addr;
	}

	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	public String getAddr() {
		return addr;
	}

	public void setAddr(String addr) {
		this.addr = addr;
	}
	
}
