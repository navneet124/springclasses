package collecton;

import java.util.*;
import java.util.Map.Entry;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class GetSnacks {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext context=new ClassPathXmlApplicationContext("snacks.xml");
		SnacksBar snk=(SnacksBar)context.getBean("snkBean");
		
		List <String> chklst=snk.getChocolates();
		
		System.out.println("chocolates available :");
		//using for each loop
		for(String c:chklst){
			System.out.println(c);
		}
		
		Set <String> s1=snk.getHotDrinks();
		System.out.println("hot drinks available :");
			 Iterator<String> i=s1.iterator();  
	           while(i.hasNext())  
	           {  
	           System.out.println(i.next());  
	           }  
	
	           
	    Map<Integer, String> m1=snk.getBhel();
	    
	    System.out.println("bhel available :");
	    for(Map.Entry m:m1.entrySet()){    
	        System.out.println(m.getKey()+" "+m.getValue());    
	       }  
	    //another way to fetch map data
	    Set<Entry<Integer, String>> s=m1.entrySet();
	    Iterator <Entry<Integer, String>> it=s.iterator();
	    
	    while(it.hasNext()){
	    	System.out.println(it.next());  
	    }
	    
		}
	}


