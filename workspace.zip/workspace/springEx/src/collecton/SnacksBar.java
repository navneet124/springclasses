package collecton;

import java.util.*;

public class SnacksBar {

	private List<String> chocolates;
	private Set<String> hotDrinks;
	private Map<Integer, String> bhel;
	
	public SnacksBar(List<String> chocolates, Set<String> hotDrinks, Map<Integer, String> bhel) {
		super();
		this.chocolates = chocolates;
		this.hotDrinks = hotDrinks;
		this.bhel = bhel;
	}

	public Map getBhel() {
		return bhel;
	}

	public void setBhel(Map bhel) {
		this.bhel = bhel;
	}

	public Set getHotDrinks() {
		return hotDrinks;
	}

	public void setHotDrinks(Set hotDrinks) {
		this.hotDrinks = hotDrinks;
	}

	public SnacksBar() {
		super();	
	}

	public List<String> getChocolates() {
		return chocolates;
	}

	public void setChocolates(List<String> chocolates) {
		this.chocolates = chocolates;
	}
}
