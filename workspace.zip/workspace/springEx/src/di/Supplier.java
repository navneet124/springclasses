package di;

public class Supplier {
	private String sname,sadd;
	private long number;
	
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String getSadd() {
		return sadd;
	}
	public void setSadd(String sadd) {
		this.sadd = sadd;
	}
	public long getNumber() {
		return number;
	}
	public void setNumber(long number) {
		this.number = number;
	}
	public Supplier(String sname, String sadd, long number) {
		super();
		this.sname = sname;
		this.sadd = sadd;
		this.number = number;
	}
	
	public Supplier(){}
}
