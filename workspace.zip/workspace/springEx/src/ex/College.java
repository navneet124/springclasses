package ex;

public class College {
	private String regno,name,addr,phn;
	private Teacher t;
	private Student s;
	
	public College(){}
	public College(String regno, String name, String addr, String phn, Teacher t, Student s) {
		super();
		this.regno = regno;
		this.name = name;
		this.addr = addr;
		this.phn = phn;
		this.t = t;
		this.s = s;
	}
	public String getRegno() {
		return regno;
	}
	public void setRegno(String regno) {
		this.regno = regno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	public String getPhn() {
		return phn;
	}
	public void setPhn(String phn) {
		this.phn = phn;
	}
	public Teacher getT() {
		return t;
	}
	public void setT(Teacher t) {
		this.t = t;
	}
	public Student getS() {
		return s;
	}
	public void setS(Student s) {
		this.s = s;
	}
}
