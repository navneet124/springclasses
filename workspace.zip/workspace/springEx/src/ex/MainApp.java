package ex;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext context=new ClassPathXmlApplicationContext("Beans2.xml");
		College c1=(College)context.getBean("colBean");
		 System.out.println("college details");
		 System.out.println("college name : "+c1.getName());
		 System.out.println("reg no : "+c1.getRegno());
		 System.out.println("college addr : "+c1.getAddr());
		 System.out.println("college phn : "+c1.getPhn());
		 
		 System.out.println("student details");
		 System.out.println("student name : "+c1.getS().getName());
		 System.out.println("student regno : "+c1.getS().getRegno());
		 System.out.println("student addr : "+c1.getS().getAddr());
		 System.out.println("student phn : "+c1.getS().getPhn());
		 System.out.println("student age : "+c1.getS().getAge());
		 
		 System.out.println("Teacher details");
		 System.out.println("Teacher name : "+c1.getT().getName());
		 System.out.println("Teacher regno : "+c1.getT().getRegno());
		 System.out.println("Teacher addr : "+c1.getT().getAddr());
		 System.out.println("Teacher phn : "+c1.getT().getPhn());
		 System.out.println("Teacher age : "+c1.getT().getAge());
		 System.out.println("Teacher dept : "+c1.getT().getDept());
	}

}
