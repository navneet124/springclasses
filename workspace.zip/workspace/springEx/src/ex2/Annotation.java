package ex2;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Annotation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext context=new AnnotationConfigApplicationContext(BillBeanConfig.class,CustomerBeanConfig.class,PurchaseBeanConfig.class,PurchaseDetailsBeanConfig.class);
		
		Bill b1=(Bill)context.getBean(Bill.class);
		System.out.println("Bill no: "+b1.getBillNo());
		System.out.println(b1.getPurDetails());
		System.out.println(b1.getPur());
		System.out.println(b1.getCust());
	}

}
