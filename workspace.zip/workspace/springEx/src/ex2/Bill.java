package ex2;

import java.util.List;
import org.springframework.beans.factory.annotation.*;

public class Bill {
	@Value("101")
	private int custCode;
	@Value("201")
	private int billNo;
	@Autowired
	private List <PurchaseDetail> purDetails;
	@Autowired
	private Purchase pur;
	@Autowired
	private Customer cust;
	
	public Purchase getPur() {
		return pur;
	}
	public void setPur(Purchase pur) {
		this.pur = pur;
	}
	public Customer getCust() {
		return cust;
	}
	public void setCust(Customer cust) {
		this.cust = cust;
	}
	
	@Autowired
	public Bill(int custCode, int billNo, List<PurchaseDetail> purDetails, Purchase pur, Customer cust) {
		super();
		this.custCode = custCode;
		this.billNo = billNo;
		this.purDetails = purDetails;
		this.pur = pur;
		this.cust = cust;
	}
	
	public int getBillNo() {
		return billNo;
	}
	public void setBillNo(int billNo) {
		this.billNo = billNo;
	}
	public int getCustCode() {
		return custCode;
	}
	public void setCustCode(int custCode) {
		this.custCode = custCode;
	}
	public List<PurchaseDetail> getPurDetails() {
		return purDetails;
	}
	public void setPurDetails(List<PurchaseDetail> purDetails) {
		this.purDetails = purDetails;
	}
	public Bill() {
		super();
	}
	
}
