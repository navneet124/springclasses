package ex2;

import org.springframework.beans.factory.annotation.Value;

public class Customer {

	@Value("Ravi")
	private String name;
	@Value("3")
	private int itemPur;
	
	public Customer() {
		super();
	}
	public Customer(String name, int itemPur) {
		super();
		this.name = name;
		this.itemPur = itemPur;
	}
	@Override
	public String toString() {
		return "Customer [name=" + name + ", itemPur=" + itemPur + "]";
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getItemPur() {
		return itemPur;
	}
	public void setItemPur(int itemPur) {
		this.itemPur = itemPur;
	}
	
}
