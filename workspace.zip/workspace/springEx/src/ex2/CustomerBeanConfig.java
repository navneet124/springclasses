package ex2;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

@Configuration
public class CustomerBeanConfig {

	@Bean
	@Scope("prototype")
	public Customer getCustomerBean()
	{
		return new Customer();
	}
}
