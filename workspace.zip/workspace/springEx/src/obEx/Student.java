package obEx;

public class Student {

	private String regno,name,addr,phn;
	private int age;
	
	public Student(){}
	public Student(String regno, String name, String addr, String phn, int age) {
		super();
		this.regno = regno;
		this.name = name;
		this.addr = addr;
		this.phn = phn;
		this.age = age;
	}
	public String getRegno() {
		return regno;
	}
	public void setRegno(String regno) {
		this.regno = regno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	public String getPhn() {
		return phn;
	}
	public void setPhn(String phn) {
		this.phn = phn;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
}
