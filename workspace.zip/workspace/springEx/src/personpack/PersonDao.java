package personpack;

import java.util.List;

public interface PersonDao {

	public int insertObj(Person p);
	public void showRecord(String pname);
	public List<Person> displayAll();
}
