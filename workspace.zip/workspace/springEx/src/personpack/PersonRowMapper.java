package personpack;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class PersonRowMapper implements RowMapper <Person>{

	@Override
	public Person mapRow(ResultSet rs, int rownum) throws SQLException {
		// TODO Auto-generated method stub
		Person p=new Person(rs.getString(1),rs.getString(2),rs.getInt(3));
		return p;
	}

}
