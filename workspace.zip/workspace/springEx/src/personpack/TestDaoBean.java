package personpack;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestDaoBean {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext context=new ClassPathXmlApplicationContext("daobean.xml");
		BusinessClass bc=(BusinessClass) context.getBean("daoBean");
		//bc.insertRow();
		//bc.firstRecord();
		System.out.println("All records");
		bc.showAll();
	}

}
