package product;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");
		 Product msg = (Product) context.getBean("productBean");
		 System.out.println(msg.getpCode());
		 System.out.println(msg.getName());
		 System.out.println(msg.getPrice());
		 
		 Product msg2 = (Product) context.getBean("productBean");
		 msg2.setpCode("p002");
		 msg2.setName("keyboard");
		 msg2.setPrice(200);
		 
		 System.out.println(msg2.getpCode());
		 System.out.println(msg2.getName());
		 System.out.println(msg2.getPrice());
		 
		 msg2.setPrice(300);
		 System.out.println(msg2.getName());
		 System.out.println(msg2.getPrice());
	}

}
