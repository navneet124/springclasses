package springEx;

public class Message {
	private String message;
	
	public Message(){}
	
	public Message(String message){
		super();
		this.message=message;
	}
	
	public void setMessage(String message) {
		this.message = message;
	}
	
	public String getMessage() {
		return message;
	}
	public void init(){
		System.out.println("initialising spring bean");
	}
	
	public void destroy(){
		System.out.println("destroying spring bean");
	}
}
